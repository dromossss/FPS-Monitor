#pragma once

namespace pmon::util::log
{
	class IChannelComponent
	{
	public:
		virtual ~IChannelComponent() = default;
	};
}