#pragma once
namespace pmon::util::pipe
{
	enum class SecurityMode
	{
		None,
		Service,
		Child,
	};
}