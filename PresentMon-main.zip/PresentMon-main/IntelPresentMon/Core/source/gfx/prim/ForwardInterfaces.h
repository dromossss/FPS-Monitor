// Copyright (C) 2022 Intel Corporation
// SPDX-License-Identifier: MIT
#pragma once

struct ID2D1Brush;
struct ID2D1SolidColorBrush;
struct ID2D1GeometryGroup;
struct ID2D1RectangleGeometry;
struct ID2D1GeometryRealization;
struct ID2D1DeviceContext2;
struct ID2D1Factory3;
struct IDWriteFactory;
struct IDWriteTextLayout;
struct IDWriteTextFormat;
