#pragma once
#include <CommonUtilities/Exception.h>


namespace p2c::gfx
{
	PM_DEFINE_EX(GraphicsException);
}