// Copyright (C) 2022 Intel Corporation
// SPDX-License-Identifier: MIT
#pragma once
#include <CommonUtilities/Exception.h>

namespace p2c::kern
{
	PM_DEFINE_EX(TargetLostException);
}