#pragma once

namespace p2c::cli
{
	int Entry(int argc, char** argv);
}