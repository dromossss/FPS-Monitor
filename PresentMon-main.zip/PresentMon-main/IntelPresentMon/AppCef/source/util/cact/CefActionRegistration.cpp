#define PM_ASYNC_ACTION_REGISTRATION_
#include "OverlayDiedAction.h"
#include "PresentmonInitFailedAction.h"
#include "StalePidAction.h"
#include "TargetLostAction.h"
#include "HotkeyFiredAction.h"