// Copyright (C) 2022 Intel Corporation
// SPDX-License-Identifier: MIT
export enum OverlayPosition {
    TopLeft,
    TopRight,
    BottomLeft,
    BottomRight,
}