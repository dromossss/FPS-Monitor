// Copyright (C) 2022 Intel Corporation
// SPDX-License-Identifier: MIT
export interface Adapter {
    id: number;
    vendor: string;
    name: string;
}